import Pokedex from './components/Pokedex'
import './App.css'

function App() {
  return (
    <div className="App">
      <Pokedex />
    </div>
  )
}

export default App

