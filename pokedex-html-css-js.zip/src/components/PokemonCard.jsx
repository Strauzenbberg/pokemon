import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';

const typeColors = {
  normal: 'bg-gray-400',
  fire: 'bg-red-500',
  water: 'bg-blue-500',
  electric: 'bg-yellow-400',
  grass: 'bg-green-500',
  ice: 'bg-blue-200',
  fighting: 'bg-red-700',
  poison: 'bg-purple-500',
  ground: 'bg-yellow-600',
  flying: 'bg-indigo-400',
  psychic: 'bg-pink-500',
  bug: 'bg-green-400',
  rock: 'bg-yellow-800',
  ghost: 'bg-purple-700',
  dragon: 'bg-indigo-700',
  dark: 'bg-gray-800',
  steel: 'bg-gray-500',
  fairy: 'bg-pink-300',
};

const PokemonCard = ({ pokemon }) => {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [showShiny, setShowShiny] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const handleImageLoad = () => {
    setImageLoaded(true);
  };

  const toggleShiny = () => {
    setShowShiny(!showShiny);
  };

  const currentSprite = showShiny ? pokemon.sprites.front_shiny : pokemon.sprites.front_default;

  return (
    <Card 
      className="w-full max-w-sm mx-auto pokemon-card-hover cursor-pointer animate-fade-in-up"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <CardHeader className="text-center pb-2">
        <CardTitle className="text-lg font-bold capitalize">
          {pokemon.name}
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          #{pokemon.id.toString().padStart(3, '0')}
        </p>
      </CardHeader>
      <CardContent className="text-center">
        <div className="relative mb-4">
          <div 
            className={`w-32 h-32 mx-auto rounded-full flex items-center justify-center transition-all duration-500 ${
              imageLoaded ? 'bg-gradient-to-br from-blue-100 to-purple-100' : 'bg-gray-200 shimmer'
            } ${isHovered ? 'animate-pulse-glow' : ''}`}
            onClick={toggleShiny}
          >
            <img
              src={currentSprite}
              alt={pokemon.name}
              className={`w-24 h-24 transition-all duration-500 ${
                imageLoaded ? 'opacity-100 scale-100' : 'opacity-0 scale-75'
              } ${showShiny ? 'filter brightness-110 saturate-150 animate-sparkle' : ''} ${
                isHovered ? 'animate-float' : ''
              }`}
              onLoad={handleImageLoad}
            />
          </div>
          {imageLoaded && (
            <div className="absolute top-2 right-2 animate-bounce-in">
              <span className={`text-xs px-2 py-1 rounded-full transition-all duration-300 ${
                showShiny ? 'bg-yellow-200 text-yellow-800 animate-sparkle' : 'bg-gray-200 text-gray-600'
              }`}>
                {showShiny ? '✨ Shiny' : 'Normal'}
              </span>
            </div>
          )}
        </div>
        
        <div className="flex flex-wrap justify-center gap-2 mb-4">
          {pokemon.types.map((type, index) => (
            <span
              key={index}
              className={`px-3 py-1 rounded-full text-white text-sm font-medium type-badge transition-all duration-300 ${
                typeColors[type.type.name] || 'bg-gray-400'
              } ${isHovered ? 'scale-105' : ''}`}
            >
              {type.type.name}
            </span>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-2 text-sm">
          <div className={`bg-muted rounded p-2 transition-all duration-300 ${
            isHovered ? 'bg-blue-50 scale-105' : ''
          }`}>
            <p className="font-semibold">Altura</p>
            <p>{(pokemon.height / 10).toFixed(1)}m</p>
          </div>
          <div className={`bg-muted rounded p-2 transition-all duration-300 ${
            isHovered ? 'bg-purple-50 scale-105' : ''
          }`}>
            <p className="font-semibold">Peso</p>
            <p>{(pokemon.weight / 10).toFixed(1)}kg</p>
          </div>
        </div>

        <div className="mt-4">
          <p className="text-xs text-muted-foreground transition-all duration-300">
            Clique na imagem para ver a versão shiny!
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default PokemonCard;

