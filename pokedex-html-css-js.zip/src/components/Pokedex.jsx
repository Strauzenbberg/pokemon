import { useState, useEffect } from 'react';
import PokemonCard from './PokemonCard';
import { Button } from '@/components/ui/button.jsx';
import { Loader2, Search, Filter } from 'lucide-react';

const Pokedex = () => {
  const [pokemon, setPokemon] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('all');

  const pokemonTypes = [
    'all', 'normal', 'fire', 'water', 'electric', 'grass', 'ice',
    'fighting', 'poison', 'ground', 'flying', 'psychic', 'bug',
    'rock', 'ghost', 'dragon', 'dark', 'steel', 'fairy'
  ];

  useEffect(() => {
    fetchPokemon();
  }, []);

  const fetchPokemon = async () => {
    try {
      setLoading(true);
      const pokemonData = [];
      
      // Buscar os primeiros 20 Pokémon
      for (let i = 1; i <= 20; i++) {
        const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${i}`);
        if (!response.ok) {
          throw new Error(`Erro ao buscar Pokémon ${i}`);
        }
        const data = await response.json();
        pokemonData.push(data);
      }
      
      setPokemon(pokemonData);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const filteredPokemon = pokemon.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === 'all' || 
      p.types.some(type => type.type.name === selectedType);
    return matchesSearch && matchesType;
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="loading-pokeball mx-auto mb-4"></div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2 animate-fade-in-up">
            Carregando Pokédex...
          </h2>
          <p className="text-gray-600 animate-fade-in-up">
            A buscar os primeiros 20 Pokémon
          </p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-pink-50 flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">😞</div>
          <h2 className="text-2xl font-bold text-red-800 mb-2">
            Erro ao carregar Pokédex
          </h2>
          <p className="text-red-600 mb-4">{error}</p>
          <Button onClick={fetchPokemon} className="bg-red-600 hover:bg-red-700">
            Tentar novamente
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      {/* Header */}
      <div className="bg-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="text-center mb-6">
            <h1 className="text-4xl font-bold text-gray-800 mb-2">
              🔴 Pokédex Interativa
            </h1>
            <p className="text-gray-600">
              Descobre os primeiros 20 Pokémon da região de Kanto
            </p>
          </div>

          {/* Filtros */}
          <div className="flex flex-col md:flex-row gap-4 max-w-2xl mx-auto">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <input
                type="text"
                placeholder="Procurar Pokémon..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="pl-10 pr-8 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
              >
                {pokemonTypes.map(type => (
                  <option key={type} value={type}>
                    {type === 'all' ? 'Todos os tipos' : type.charAt(0).toUpperCase() + type.slice(1)}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Grid de Pokémon */}
      <div className="container mx-auto px-4 py-8">
        {filteredPokemon.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">🔍</div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              Nenhum Pokémon encontrado
            </h3>
            <p className="text-gray-500">
              Tenta ajustar os teus filtros de pesquisa
            </p>
          </div>
        ) : (
          <>
            <div className="text-center mb-6">
              <p className="text-gray-600">
                A mostrar {filteredPokemon.length} de {pokemon.length} Pokémon
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6 pokemon-grid">
              {filteredPokemon.map((p) => (
                <PokemonCard key={p.id} pokemon={p} />
              ))}
            </div>
          </>
        )}
      </div>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-6 mt-12">
        <div className="container mx-auto px-4 text-center">
          <p className="mb-2">
            Dados fornecidos pela{' '}
            <a 
              href="https://pokeapi.co" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-blue-400 hover:text-blue-300 underline"
            >
              PokéAPI
            </a>
          </p>
          <p className="text-gray-400 text-sm">
            Pokédex Interativa - Criada com React e Tailwind CSS
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Pokedex;

